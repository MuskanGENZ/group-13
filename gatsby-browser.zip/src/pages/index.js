import React from "react"
import Features from "../component/Features/Features"
import Hero from "../component/Hero/Hero"
import Layout from "../component/Layout/Layout"
import Team from "../component/Team/Team"
import "./index.css"

 const Index = () => {
  return (
  
    <Layout>
  <Hero/>
  <Features/>
  <Team/>
    
    
    </Layout>
  
  
  )
}
export default Index